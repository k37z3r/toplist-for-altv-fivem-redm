fx_version 'cerulean'
game 'gta5'
name 'GTA-SPOT-Toplist-Updater'
author 'Luz Iferato'
description 'Update your Toplist entry at gta-spot.com'
url 'https://github.com/k37z3r/'
version '0.1'
server_scripts{
    'server.js',
}