1. you have to need to use jsmodule
2. if you don't have, install following NodeJS-modules: `axios`, `dotenv`
3. download this package and drag to your resource-folder
4. login at https://gta-spot.com and get secretSID and secretPID
5. open `.env`, read the instructions at top of file and do it.
6. open your `server.cfg`
7. find resources and put into the brackets: `gta-spot-toplist`
8. put at the end of server.cfg: `secretSID: 'irgfsehiurgs'` (here comes your SID in, to get your SID login at https://gta-spot.com)
9. save file and restart your server
10. login at https://gta-spot.com and edit the entries underneath "Other Data"<br><br><br>
last but not least: advertise our website to get likes by your players
